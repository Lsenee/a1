import numpy as np

class SDES:
    def __init__(self):
        # 分组长度，密钥长度
        self.BLOCK_SIZE = 8
        self.KEY_SIZE = 10
        # 子密钥生成置换盒
        self.P10 = np.array([3, 5, 2, 7, 4, 10, 1, 9, 8, 6]) - 1
        self.P8 = np.array([6, 3, 7, 4, 8, 5, 10, 9]) - 1
        # 子密钥左移位盒
        self.LEFTSHIFT1 = np.array([2, 3, 4, 5, 1]) - 1
        self.LEFTSHIFT2 = np.array([3, 4, 5, 1, 2]) - 1
        # IP置换盒
        self.IP = np.array([2, 6, 3, 1, 4, 8, 5, 7]) - 1
        self.IP_1 = np.array([4, 1, 3, 5, 7, 2, 8, 6]) - 1
        # F轮函数盒
        self.EPBox = np.array([4, 1, 2, 3, 2, 3, 4, 1]) - 1
        self.SBox1 = np.array([[1, 0, 3, 2],
                               [3, 2, 1, 0],
                               [0, 2, 1, 3],
                               [3, 1, 0, 2]])
        self.SBox2 = np.array([[0, 1, 2, 3],
                               [2, 3, 1, 0],
                               [3, 0, 1, 2],
                               [2, 1, 0, 3]])
        self.SPBox = np.array([2, 4, 3, 1]) - 1

    def encrypt(self, plaintext: str, key: str) -> str:
        # 数据检验
        if len(plaintext) % self.BLOCK_SIZE != 0:
            raise ValueError(f"输入字符串长度必须是{self.BLOCK_SIZE}bit的倍数")
        if len(key) != self.KEY_SIZE:
            raise ValueError(f"密钥长度必须是{self.KEY_SIZE}bit")

        # 数据转换(str->array)
        plain_array = np.array(list(plaintext), dtype=int).reshape(-1, self.BLOCK_SIZE)
        key_array = np.array(list(key), dtype=int).reshape(-1, self.KEY_SIZE)

        # 子密钥生成
        subkey1, subkey2 = self.generate_subkey(key_array)

        # IP置换
        ip8 = plain_array[:, self.IP]
        L0, R0 = ip8[:, :4], ip8[:, 4:]

        # 下一轮输入L1,R1
        L1 = R0
        R1 = L0 ^ self.F(R0, subkey1)

        # 下一轮输入L2,R2
        L2 = L1 ^ self.F(R1, subkey2)
        R2 = R1

        # IP_1置换
        ip8_1 = np.hstack((L2, R2))[:, self.IP_1]

        return ''.join(ip8_1.astype(str).flatten())

    def decrypt(self, ciphertext: str, key: str) -> str:
        """解密函数，输入密文和密钥，返回明文"""
        # 数据检验
        if len(ciphertext) % self.BLOCK_SIZE != 0:
            raise ValueError(f"输入字符串长度必须是{self.BLOCK_SIZE}bit的倍数")
        if len(key) != self.KEY_SIZE:
            raise ValueError(f"密钥长度必须是{self.KEY_SIZE}bit")

        # 数据转换(str->array)
        plain_array = np.array(list(ciphertext), dtype=int).reshape(-1, self.BLOCK_SIZE)
        key_array = np.array(list(key), dtype=int).reshape(-1, self.KEY_SIZE)

        # 子密钥生成
        subkey1, subkey2 = self.generate_subkey(key_array)

        # IP置换
        ip8 = plain_array[:, self.IP]
        L0, R0 = ip8[:, :4], ip8[:, 4:]

        # 解密使用密钥顺序与加密相反
        # 下一轮输入L1,R1
        L1 = R0
        R1 = L0 ^ self.F(R0, subkey2)

        # 下一轮输入L2,R2
        L2 = L1 ^ self.F(R1, subkey1)
        R2 = R1

        # IP_1置换
        ip8_1 = np.hstack((L2, R2))[:, self.IP_1]

        return ''.join(ip8_1.astype(str).flatten())

    def generate_subkey(self, key_array: np.ndarray) -> tuple:
        """生成子密钥，输入密钥数组，返回子密钥1和子密钥2"""
        # P10置换
        key10 = key_array[:, self.P10]
        # 左移一次
        left1 = key10[:, :5][:, self.LEFTSHIFT1]
        right1 = key10[:, 5:][:, self.LEFTSHIFT1]

        # 左移两次
        left2 = left1[:, self.LEFTSHIFT2]
        right2 = right1[:, self.LEFTSHIFT2]

        # P8置换
        key8_1 = np.hstack((left1, right1))[:, self.P8]
        key8_2 = np.hstack((left2, right2))[:, self.P8]

        return key8_1, key8_2

    def F(self, R: np.ndarray, subkey: np.ndarray) -> np.ndarray:
        """F函数，输入右半部分R和子密钥，返回输出"""
        # EPBox扩展置换盒
        R_ext = R[:, self.EPBox]

        # 异或操作
        R_xor = R_ext ^ subkey

        # SBox1,SBox2
        # 提取SBox1的输入位 (0,3)为行，(1,2)为列
        s1_rows = (R_xor[:, 0] << 1) | R_xor[:, 3]
        s1_cols = (R_xor[:, 1] << 1) | R_xor[:, 2]
        # 提取SBox2的输入位 (4,7)为行，(5,6)为列
        s2_rows = (R_xor[:, 4] << 1) | R_xor[:, 7]
        s2_cols = (R_xor[:, 5] << 1) | R_xor[:, 6]

        # S盒查询
        s1_output = self.SBox1[s1_rows, s1_cols]
        s2_output = self.SBox2[s2_rows, s2_cols]

        # 合并S盒输出
        combined = (s1_output << 2) | s2_output
        # 转为二进制数组
        sboxs = np.array([list(f"{x:04b}") for x in combined.flatten()], dtype=int).reshape(-1, 4)

        # SPbox置换
        spbox = sboxs[:, self.SPBox]
        return spbox

    def ascii_to_binary(self, text: str) -> str:
        """将ASCII字符串转换为二进制字符串"""
        binary_str = ""
        for char in text:
            # 将每个字符转换为8位二进制
            binary_char = format(ord(char), '08b')
            binary_str += binary_char
        return binary_str

    def binary_to_ascii(self, binary_str: str) -> str:
        """将二进制字符串转换为ASCII字符串"""
        # 确保二进制字符串长度是8的倍数
        if len(binary_str) % 8 != 0:
            raise ValueError("二进制字符串长度必须是8的倍数")
        
        ascii_str = ""
        for i in range(0, len(binary_str), 8):
            # 每8位转换为一个字符
            byte = binary_str[i:i+8]
            char_code = int(byte, 2)
            # 对非ASCII字符（>127）和不可打印字符使用转义序列
            # 保留制表符(9)、换行符(10)、回车符(13)
            if char_code > 127 or (char_code < 32 and char_code not in [9, 10, 13]):
                ascii_str += f"\\x{char_code:02x}"
            else:
                ascii_str += chr(char_code)
        return ascii_str

    def key_to_binary(self, key_str: str) -> str:
        """将ASCII密钥字符串转换为10位二进制密钥"""
        # 检查是否已经是二进制字符串（只包含0和1）
        if all(c in '01' for c in key_str) and len(key_str) == 10:
            # 如果已经是10位二进制字符串，直接返回
            return key_str
        
        # 将ASCII密钥转换为二进制
        binary_key = ""
        for char in key_str:
            binary_key += format(ord(char), '08b')
        
        # 如果二进制密钥长度超过10位，取前10位
        if len(binary_key) > 10:
            binary_key = binary_key[:10]
        # 如果不足10位，用0填充
        elif len(binary_key) < 10:
            binary_key = binary_key.ljust(10, '0')
        
        return binary_key

    def encrypt_ascii(self, text: str, key: str) -> str:
        """加密ASCII字符串"""
        # 将密钥转换为10位二进制
        binary_key = self.key_to_binary(key)
        
        # 将ASCII文本转换为二进制
        binary_text = self.ascii_to_binary(text)
        
        # 使用现有的加密方法
        encrypted_binary = self.encrypt(binary_text, binary_key)
        
        # 将加密后的二进制转换为ASCII字符串
        encrypted_ascii = self.binary_to_ascii(encrypted_binary)
        
        return encrypted_ascii

    def decrypt_ascii(self, ciphertext: str, key: str) -> str:
        """解密ASCII字符串"""
        # 将密钥转换为10位二进制
        binary_key = self.key_to_binary(key)
        
        # 将密文字符串转换为二进制（需要处理转义序列）
        binary_cipher = self.ascii_to_binary_with_escape(ciphertext)
        
        # 使用现有的解密方法
        decrypted_binary = self.decrypt(binary_cipher, binary_key)
        
        # 将解密后的二进制转换为ASCII字符串
        decrypted_ascii = self.binary_to_ascii(decrypted_binary)
        
        return decrypted_ascii

    def ascii_to_binary_with_escape(self, text: str) -> str:
        """将包含转义序列的ASCII字符串转换为二进制字符串"""
        binary_str = ""
        i = 0
        while i < len(text):
            if text[i] == '\\' and i + 3 < len(text) and text[i+1] == 'x':
                # 处理转义序列 \xHH
                hex_str = text[i+2:i+4]
                char_code = int(hex_str, 16)
                binary_str += format(char_code, '08b')
                i += 4
            else:
                # 处理普通字符
                binary_str += format(ord(text[i]), '08b')
                i += 1
        return binary_str


# 测试SDES实现
my_sdes = SDES()
plain = '11101010'
key = '0111111101'
cipher = my_sdes.encrypt(plain, key)
print(cipher)
p = my_sdes.decrypt(cipher, key)
print(p)

# ASCII encryption function test
print("\n" + "="*50)
print("ASCII Encryption Function Test")
print("="*50)

# Test 1: English text
print("\nTest 1: English Text Encryption Decryption")
ascii_plain1 = "Hello World"
ascii_key1 = "1010101010"
print(f"Plaintext: '{ascii_plain1}'")
print(f"Key: '{ascii_key1}'")

ascii_cipher1 = my_sdes.encrypt_ascii(ascii_plain1, ascii_key1)
print(f"Ciphertext: '{ascii_cipher1}'")

ascii_decrypted1 = my_sdes.decrypt_ascii(ascii_cipher1, ascii_key1)
print(f"Decrypted: '{ascii_decrypted1}'")
print(f"Encryption/Decryption Success: {ascii_plain1 == ascii_decrypted1}")

# Test 2: Contains special characters
print("\nTest 2: Text with Special Characters")
ascii_plain2 = "Test123!@#"
ascii_key2 = "1100110011"
print(f"Plaintext: '{ascii_plain2}'")
print(f"Key: '{ascii_key2}'")

ascii_cipher2 = my_sdes.encrypt_ascii(ascii_plain2, ascii_key2)
print(f"Ciphertext: '{ascii_cipher2}'")

ascii_decrypted2 = my_sdes.decrypt_ascii(ascii_cipher2, ascii_key2)
print(f"Decrypted: '{ascii_decrypted2}'")
print(f"Encryption/Decryption Success: {ascii_plain2 == ascii_decrypted2}")

# Test 3: Using ASCII key
print("\nTest 3: Using ASCII Key")
ascii_plain3 = "Secret"
ascii_key3 = "abc"  # 会被转换为10位二进制
print(f"Plaintext: '{ascii_plain3}'")
print(f"ASCII Key: '{ascii_key3}'")

binary_key3 = my_sdes.key_to_binary(ascii_key3)
print(f"Converted Binary Key: {binary_key3}")

ascii_cipher3 = my_sdes.encrypt_ascii(ascii_plain3, ascii_key3)
print(f"Ciphertext: '{ascii_cipher3}'")

ascii_decrypted3 = my_sdes.decrypt_ascii(ascii_cipher3, ascii_key3)
print(f"Decrypted: '{ascii_decrypted3}'")
print(f"Encryption/Decryption Success: {ascii_plain3 == ascii_decrypted3}")

print("\n" + "="*50)
print("All Tests Completed")
print("="*50)
