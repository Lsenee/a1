import sys
import SDESDialog
from PyQt5.QtWidgets import QApplication, QDialog


class MainDialog(QDialog):
    def __init__(self, parent=None):
        super(QDialog, self).__init__(parent)
        self.ui = SDESDialog.Ui_SDESDialog()
        self.ui.setupUi(self)


if __name__ == '__main__':
    myapp = QApplication(sys.argv)
    myDlg = MainDialog()
    with open('./style.qss', 'r', encoding='UTF-8') as f:
        myDlg.setStyleSheet(f.read())
    myDlg.show()
    sys.exit(myapp.exec_())
