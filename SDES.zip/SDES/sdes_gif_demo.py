#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import random
import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.animation import FuncAnimation
from PIL import Image
import os
from SDES import SDES

class SDESGIFDemo:
    def __init__(self):
        self.sdes = SDES()
        self.total_keys = 1024  # 2^10 possible keys
        self.frames = []
        self.progress_data = []
        
    def generate_key_space(self):
        """生成所有可能的10位二进制密钥"""
        return [format(i, '010b') for i in range(self.total_keys)]
    
    def create_test_case(self, ensure_success_in_range=True):
        """创建一个测试用例，可选确保密钥在前200个范围内"""
        if ensure_success_in_range:
            # 确保密钥在前200个范围内，保证演示成功
            true_key_index = random.randint(50, 180)  # 在50-180之间，避免太早或太晚
            true_key = format(true_key_index, '010b')
        else:
            true_key = format(random.randint(0, 1023), '010b')
            
        plaintext = format(random.randint(0, 255), '08b')
        ciphertext = self.sdes.encrypt(plaintext, true_key)
        
        return {
            'plaintext': plaintext,
            'ciphertext': ciphertext,
            'true_key': true_key
        }
    
    def verify_key(self, key, test_case):
        """验证密钥是否正确"""
        try:
            decrypted = self.sdes.decrypt(test_case['ciphertext'], key)
            return decrypted == test_case['plaintext']
        except:
            return False
    
    def create_progress_animation(self, test_case, output_path="sdes_bruteforce.gif"):
        """创建暴力破解进度动画"""
        print("\n" + "=" * 60)
        print("Starting S-DES Brute Force Attack")
        print("=" * 60)
        print(f"True Key: {test_case['true_key']}")
        print(f"Plaintext: {test_case['plaintext']}")
        print(f"Ciphertext: {test_case['ciphertext']}")
        print(f"Total key space: {self.total_keys} possible keys")
        
        keys = self.generate_key_space()
        start_time = time.time()
        found_key = None
        attempts = 0
        
        # 设置matplotlib图形
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
        plt.subplots_adjust(hspace=0.4)
        
        def update(frame):
            nonlocal found_key, attempts
            
            if found_key is not None:
                return
            
            # 尝试下一个密钥
            current_key = keys[frame]
            attempts = frame + 1
            is_correct = self.verify_key(current_key, test_case)
            
            if is_correct:
                found_key = current_key
                print(f"\n[SUCCESS] Found key at attempt {attempts}: {found_key}")
            
            # 更新进度数据
            elapsed = time.time() - start_time
            speed = attempts / elapsed if elapsed > 0 else 0
            
            self.progress_data.append({
                'attempt': attempts,
                'elapsed': elapsed,
                'speed': speed,
                'found': is_correct
            })
            
            # 每50次尝试显示一次进度
            if attempts % 50 == 0:
                progress = attempts / self.total_keys
                print(f"Progress: {attempts}/{self.total_keys} ({progress:.1%}) - Time: {elapsed:.2f}s - Speed: {speed:.1f} keys/sec")
            
            # 清空图形
            ax1.clear()
            ax2.clear()
            
            # 绘制进度条
            progress = attempts / self.total_keys
            ax1.barh(['Progress'], [progress], color='skyblue', alpha=0.7)
            ax1.barh(['Progress'], [1 - progress], left=[progress], color='lightgray', alpha=0.3)
            ax1.set_xlim(0, 1)
            ax1.set_title(f'S-DES Brute Force Progress: {progress:.1%}', fontsize=14, fontweight='bold')
            ax1.text(0.5, 0, f'Attempts: {attempts}/{self.total_keys}', 
                    ha='center', va='bottom', transform=ax1.transAxes, fontsize=12)
            
            # 绘制速度和密钥信息
            attempt_data = [d['attempt'] for d in self.progress_data]
            speeds = [d['speed'] for d in self.progress_data]
            
            ax2.plot(attempt_data, speeds, 'b-', linewidth=2, label='Keys per second')
            ax2.set_xlabel('Attempts')
            ax2.set_ylabel('Keys/Second')
            ax2.set_title('Brute Force Speed', fontsize=12)
            ax2.legend()
            ax2.grid(True, alpha=0.3)
            
            # 添加信息文本
            info_text = f"""
Current Key: {current_key}
Elapsed Time: {elapsed:.2f}s
Current Speed: {speed:.1f} keys/sec
Status: {'FOUND!' if is_correct else 'Searching...'}
            """
            
            plt.figtext(0.02, 0.02, info_text, fontsize=10, 
                       bbox=dict(boxstyle="round,pad=0.3", facecolor="lightyellow", alpha=0.7))
            
            if is_correct:
                plt.figtext(0.5, 0.5, 'KEY FOUND!', fontsize=20, 
                           ha='center', va='center', 
                           bbox=dict(boxstyle="round,pad=1", facecolor="lightgreen", alpha=0.9))
        
        # 创建动画
        print("\nCreating animation frames...")
        max_frames = min(200, len(keys))
        print(f"Will create {max_frames} animation frames")
        
        animation = FuncAnimation(fig, update, frames=max_frames, 
                                interval=100, repeat=False)
        
        # 保存为GIF
        print(f"\nSaving animation to {output_path}...")
        animation.save(output_path, writer='pillow', fps=10, dpi=100)
        plt.close()
        
        # 最终统计信息
        total_time = time.time() - start_time
        print("\n" + "=" * 60)
        print("Brute Force Attack Completed")
        print("=" * 60)
        print(f"Animation saved successfully!")
        print(f"Total attempts in animation: {attempts}")
        if found_key:
            print(f"Final key found: {found_key}")
            print(f"Verification: {found_key == test_case['true_key']}")
        else:
            print("Key not found in animation frames (may be found in later attempts)")
        print(f"Total time: {total_time:.4f} seconds")
        print(f"Average speed: {attempts/total_time:.2f} keys/second")
        
        return found_key

def main():
    """主演示函数"""
    print("=" * 60)
    print("S-DES Brute Force GIF Demonstration")
    print("=" * 60)
    
    # 创建演示器
    demo = SDESGIFDemo()
    
    # 创建测试用例
    test_case = demo.create_test_case()
    
    print("\nTest Case Information:")
    print(f"True Key: {test_case['true_key']}")
    print(f"Plaintext: {test_case['plaintext']}")
    print(f"Ciphertext: {test_case['ciphertext']}")
    
    # 生成GIF动画
    output_file = "sdes_bruteforce_demo.gif"
    found_key = demo.create_progress_animation(test_case, output_file)
    
    # 验证结果
    print("\n" + "=" * 60)
    print("Result Verification")
    print("=" * 60)
    
    if found_key == test_case['true_key']:
        print("[SUCCESS] Brute force demonstration completed successfully!")
        print(f"GIF animation saved as: {output_file}")
    else:
        print("[FAILED] Brute force demonstration failed")
    
    print("\nTo view the animation:")
    print(f"1. Open {output_file} in any image viewer")
    print("2. The animation shows the brute force progress in real-time")
    print("3. Green highlight appears when the correct key is found")

if __name__ == "__main__":
    main()
